---
name: Atelier Curatorial
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5d5f5d'
  on-secondary: '#ffffff'
  secondary-container: '#e2e3e1'
  on-secondary-container: '#636563'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1c1c'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e2e3e1'
  secondary-fixed-dim: '#c6c7c5'
  on-secondary-fixed: '#1a1c1b'
  on-secondary-fixed-variant: '#454746'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c7c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
spacing:
  unit: 8px
  container-padding-desktop: 80px
  container-padding-mobile: 24px
  gutter: 32px
  section-gap: 120px
---

## Brand & Style

The design system is rooted in the philosophy of the "White Cube" gallery—a space where the container is secondary to the content, yet meticulously crafted. It targets a sophisticated audience that values intellectual clarity, artistic rigor, and quiet luxury.

The visual style is a blend of **Minimalism** and **Architectural Structuralism**. It leverages expansive whitespace to create "breathing room" between ideas, much like the physical distance between paintings in a contemporary wing. The emotional response is one of calm, focused attention and institutional authority. Every element is intentional; there is no decoration for decoration’s sake.

Key aesthetic principles include:
- **Spatial Generosity:** Extreme margins and padding to signal premium value.
- **Structural Framing:** Use of thin, architectural lines to define boundaries without heavy containers.
- **Curatorial Focus:** High-contrast typography that mirrors gallery wall vinyls and labels.

## Colors

The palette is strictly monochromatic and environmental, designed to disappear behind photography or data while providing a rigid structural framework.

- **Gallery White (#FFFFFF):** The primary background color, representing the pristine walls of a contemporary space.
- **Off-White / Paper (#F9F9F7):** Used for subtle layering, resembling high-grade archival paper or concrete flooring.
- **Architectural Grey (#8C8C8C):** Used for metadata, borders, and secondary information. It provides a soft, structural presence.
- **Deep Charcoal (#1A1A1A):** The primary color for text and critical interactive elements, offering maximum contrast against the white canvas.

Avoid gradients or vibrant accent colors. Depth is achieved through value shifts and shadows rather than hue.

## Typography

The typographic system creates a hierarchy of "Title, Text, and Catalog."

1.  **Headlines (Playfair Display):** A sophisticated, high-contrast serif. Used for page titles and major sections to evoke the elegance of a gallery wall.
2.  **Body (Work Sans):** A reliable, legible sans-serif that remains neutral and transparent, allowing long-form content to be consumed without distraction.
3.  **Labels (JetBrains Mono):** A monospaced font used for metadata, dates, and "catalog" information. This adds a technical, curated feel to the interface.

**Scaling:** On mobile, display sizes scale down significantly to maintain the "airy" feel without overwhelming the smaller viewport. Line heights are kept generous (approx. 1.6x for body) to ensure a feeling of openness.

## Layout & Spacing

This design system utilizes a **Fixed Grid** model on desktop (12 columns, 1200px max-width) to ensure content remains centered and focused like an island in a vast hall.

The spacing rhythm is intentional and wide.
- **Generous Margins:** Page gutters are unusually large (80px+) to isolate content from the edges of the screen.
- **Negative Space:** Sections are separated by large gaps (120px) to force a pause in the user's journey, emphasizing each "exhibit."
- **Adaptive Reflow:** On tablet, the grid shifts to 8 columns with 40px margins. On mobile, it moves to 4 columns with 24px margins, maintaining the priority of vertical flow and whitespace.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** and **Ambient Shadows** rather than traditional elevation.

- **The Floor:** The primary background is the lowest level (Gallery White).
- **The Plinth:** Interactive cards or "exhibits" sit on a secondary level. They do not use heavy borders; instead, they use an extremely diffused, low-opacity shadow (#000000 at 4% opacity, 40px blur) to appear as if they are floating slightly off the wall.
- **Framing:** Fine 1px lines in Architectural Grey (#8C8C8C) are used to "frame" content blocks, mimicking the thin metal frames of modern art.
- **Overlays:** Modals and menus use a high-transparency backdrop blur to maintain a sense of the space behind them, ensuring the user never feels "closed in."

## Shapes

The shape language is strictly **Sharp (0px roundedness)**. 

To mirror the architecture of modern museums—often defined by sharp angles, straight lines, and rectangular volumes—every UI component features 90-degree corners. This includes buttons, input fields, images, and cards. This lack of "softness" reinforces the institutional and intellectual nature of the design.

## Components

### Buttons
Primary buttons are solid Deep Charcoal (#1A1A1A) with white text. They are rectangular with no border radius. Hover states should involve a subtle shift to Architectural Grey or an inverted style (Outline).

### Cards (Exhibits)
Cards are "frameless" or defined by a very thin 1px Architectural Grey border. They should have ample internal padding (32px or more) to ensure the content within feels like an isolated work of art.

### Input Fields
Inputs are minimalist, consisting only of a bottom border (1px) in Architectural Grey. Labels use the Monospaced font (JetBrains Mono) placed above the line in a small, all-caps format.

### Elegant Labels
Use the Monospaced font for all metadata. For example, a date on a blog post should look like a catalog entry: `[ 2024.10.12 ]`.

### Lists
Lists are separated by horizontal 1px lines that span the full width of the container, creating a clean, ledger-like appearance. Avoid bullets; use the monospaced labels for numbering or categorization.